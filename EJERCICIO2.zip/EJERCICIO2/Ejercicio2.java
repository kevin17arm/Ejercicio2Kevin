/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Formacion
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Agapito Piedralisa", "c/ Río Seco, 2", "123456789");
        Factura factura = new Factura(cliente, "18/4/2011");

        factura.anyadirLinea(1, "Ratón USB", 8.43f);
        factura.anyadirLinea(2, "Memoria RAM 2GB", 21.15f);
        factura.anyadirLinea(1, "Altavoces", 12.66f);

        factura.imprimirFactura();
    }
    
}
