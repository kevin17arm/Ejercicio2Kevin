/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Formacion
 */
public class Factura {
    static int sigid = 12345;
    static final int IVA = 18;

    String fecha;
    int id;
    Cliente cliente;
    List<Linea> lineas = new ArrayList<>();

    public Factura(Cliente c, String fecha) {
        this.fecha = fecha;
        this.cliente = c;
        this.id = getSigid();
    }

    public void anyadirLinea(int cant, String desc, float precio) {
        Linea linea = new Linea();
        linea.setCantidad(cant);
        linea.setDescripcion(desc);
        linea.setPrecio(precio);
        lineas.add(linea);
    }

    public static int getSigid() {
        return sigid++;
    }

    public void imprimirFactura() {
        System.out.println("Factura nº: " + id);
        System.out.println("Fecha: " + fecha);
        System.out.println("\nDatos del cliente");
        System.out.println("------------------------");
        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Dirección: " + cliente.getDireccion());
        System.out.println("Teléfono: " + cliente.getTelefono());

        System.out.println("\nDetalle de la factura");
        System.out.println("------------------------");
        System.out.println("Línea;Producto;Cantidad;Precio ud.;Precio total");
        System.out.println("--");

        float subtotal = 0;
        int i = 1;
        for (Linea l : lineas) {
            float totalLinea = l.getSubtotal();
            System.out.printf("%d;%s;%d;%.2f;%.2f\n", i++, l.getDescripcion(), l.getCantidad(), l.getPrecio(), totalLinea);
            subtotal += totalLinea;
        }

        float iva = subtotal * IVA / 100;
        float total = subtotal + iva;

        System.out.printf("\nSubtotal: %.2f €\n", subtotal);
        System.out.printf("IVA (%d%%): %.2f €\n", IVA, iva);
        System.out.printf("TOTAL: %.4f €\n", total);
    }
}

